// خفيف ومتكامل: timeout, retries with exponential backoff + jitter,
// concurrency limit, circuit breaker, fallback URLs.
// استخدمه كبديل للدالة callAPI في صفحتك (استبدل callAPI(...) بـ apiClient.request(...))

const apiClient = (() => {
  // Configuration defaults
  const DEFAULTS = {
    timeout: 10000,             // ms قبل إلغاء الطلب
    retries: 3,                 // عدد المحاولات (إجمالي)
    backoffBase: 300,           // ms
    backoffMax: 5000,           // ms
    jitter: true,               // true => add random jitter
    concurrency: 6,             // عدد الطلبات المتزامنة القصوى
    circuitThreshold: 5,        // عدد الأخطاء المتتالية لفتح الدائرة
    circuitResetMs: 30_000,     // كم تبقى الدائرة مفتوحة قبل تجربة ثانية
    fallbackUrls: []            // optional array of fallback urls (string prefix)
  };

  // Internal state
  let inFlight = 0;
  const queue = [];
  let circuit = {
    failures: 0,
    state: 'CLOSED', // CLOSED | OPEN | HALF
    openedAt: 0
  };

  function wait(ms) {
    return new Promise(res => setTimeout(res, ms));
  }

  function now() { return Date.now(); }

  function calcBackoff(attempt, base, max, jitter) {
    const exp = Math.min(max, base * (2 ** (attempt - 1)));
    if (!jitter) return exp;
    // full jitter
    return Math.floor(Math.random() * exp);
  }

  async function runQueue() {
    if (inFlight >= DEFAULTS.concurrency) return;
    const next = queue.shift();
    if (!next) return;
    inFlight++;
    try {
      const res = await next.fn();
      next.resolve(res);
    } catch (err) {
      next.reject(err);
    } finally {
      inFlight--;
      // next tick to avoid deep recursion
      setTimeout(runQueue, 0);
    }
  }

  function enqueue(fn) {
    return new Promise((resolve, reject) => {
      queue.push({ fn, resolve, reject });
      runQueue();
    });
  }

  function shouldShortCircuit() {
    if (circuit.state === 'OPEN') {
      // if reset timeout passed, move to HALF
      if (now() - circuit.openedAt > DEFAULTS.circuitResetMs) {
        circuit.state = 'HALF';
        return false;
      }
      return true;
    }
    return false;
  }

  function recordSuccess() {
    circuit.failures = 0;
    if (circuit.state === 'HALF') circuit.state = 'CLOSED';
  }

  function recordFailure() {
    circuit.failures++;
    if (circuit.failures >= DEFAULTS.circuitThreshold) {
      circuit.state = 'OPEN';
      circuit.openedAt = now();
    }
  }

  // main request function
  async function request(url, opts = {}, cfg = {}) {
    const settings = { ...DEFAULTS, ...cfg };
    if (shouldShortCircuit()) {
      throw new Error('Service temporarily unavailable (circuit open)');
    }

    // attempt function does one attempt (with AbortController timeout)
    const attemptFetch = async (fullUrl, attemptNo) => {
      const controller = new AbortController();
      const to = setTimeout(() => controller.abort(), settings.timeout);
      try {
        const fetchOpts = Object.assign({}, opts, { signal: controller.signal });
        const resp = await fetch(fullUrl, fetchOpts);
        clearTimeout(to);
        if (!resp.ok) {
          // For 5xx or 429 we may want to retry; for 4xx probably not
          const errText = await resp.text().catch(() => '');
          const err = new Error(`HTTP ${resp.status} ${errText || resp.statusText}`);
          err.status = resp.status;
          throw err;
        }
        // Try parse JSON; fallback to text
        const ct = resp.headers.get('content-type') || '';
        if (ct.includes('application/json')) {
          return await resp.json();
        } else {
          return await resp.text();
        }
      } catch (err) {
        clearTimeout(to);
        // rethrow error
        throw err;
      }
    };

    // Wrap into retries and fallbacks
    const exec = async () => {
      let lastErr = null;

      // Build candidate URLs: main + fallbacks
      const candidates = [url].concat(settings.fallbackUrls || []);
      for (let candidateIdx = 0; candidateIdx < candidates.length; candidateIdx++) {
        const baseUrl = candidates[candidateIdx];
        for (let attempt = 1; attempt <= settings.retries; attempt++) {
          try {
            const fullUrl = baseUrl;
            const res = await attemptFetch(fullUrl, attempt);
            // success
            recordSuccess();
            return res;
          } catch (err) {
            lastErr = err;
            const status = err && err.status;
            // Decide whether to retry:
            // Retry on network error, AbortError, 5xx, 429
            const isNetwork = err.name === 'AbortError' || err instanceof TypeError;
            const retryableStatus = status >= 500 || status === 429 || typeof status === 'undefined';
            if (!isNetwork && !retryableStatus) {
              // not worth retrying this candidate (e.g., 400)
              break;
            }
            // backoff before next attempt (unless last attempt for this candidate)
            if (attempt < settings.retries) {
              const delay = calcBackoff(attempt, settings.backoffBase, settings.backoffMax, settings.jitter);
              await wait(delay);
              continue;
            }
            // else try next candidate (fallback URL)
          }
        }
      }
      // All candidates exhausted
      recordFailure();
      throw lastErr || new Error('Request failed');
    };

    // run respecting concurrency queue
    return enqueue(exec);
  }

  return {
    request,
    // helpers to override defaults if needed
    defaults: DEFAULTS,
    getCircuitState: () => ({ ...circuit }),
    // allow updating fallback URLs at runtime
    setFallbacks(urls) { DEFAULTS.fallbackUrls = Array.isArray(urls) ? urls : []; }
  };
})();