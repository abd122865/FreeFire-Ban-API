// common.js — helper UI functions (safe rendering)

function showToast(message, type = 'success') {
  const containerId = '__supra_toast_container';
  let container = document.getElementById(containerId);
  if (!container) {
    container = document.createElement('div');
    container.id = containerId;
    Object.assign(container.style, { position: 'fixed', right: '12px', top: '12px', zIndex: 9999 });
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.textContent = message;
  el.style.marginBottom = '8px';
  el.style.padding = '10px 12px';
  el.style.borderRadius = '8px';
  el.style.color = '#fff';
  el.style.background = type === 'success' ? '#059669' : '#DC2626';
  container.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

function setLoading(show) {
  const id = '__supra_loader';
  let overlay = document.getElementById(id);
  if (show) {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = id;
      Object.assign(overlay.style, {
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex',
        alignItems: 'center', justifyContent: 'center', zIndex: 9998
      });
      const box = document.createElement('div');
      box.textContent = 'Processing...';
      box.style.color = '#fff';
      box.style.padding = '18px 22px';
      box.style.borderRadius = '8px';
      overlay.appendChild(box);
      document.body.appendChild(overlay);
    }
  } else if (overlay) {
    overlay.remove();
  }
}

function createResultBox(containerId, data, isSuccess = true) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';
  container.style.display = 'block';

  const wrapper = document.createElement('div');
  wrapper.style.marginTop = '12px';
  wrapper.style.padding = '12px';
  wrapper.style.borderRadius = '12px';
  wrapper.style.background = isSuccess ? 'rgba(16,185,129,0.07)' : 'rgba(239,68,68,0.07)';
  wrapper.style.border = `1px solid ${isSuccess ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)'}`;

  const header = document.createElement('div');
  header.style.display = 'flex';
  header.style.justifyContent = 'space-between';
  header.style.marginBottom = '8px';

  const status = document.createElement('strong');
  status.textContent = isSuccess ? 'Success' : 'Error';
  header.appendChild(status);

  const controls = document.createElement('div');

  const copyBtn = document.createElement('button');
  copyBtn.textContent = 'Copy';
  copyBtn.style.marginRight = '8px';
  copyBtn.addEventListener('click', () => {
    const text = (typeof data === 'object') ? JSON.stringify(data, null, 2) : String(data);
    navigator.clipboard?.writeText(text).then(() => showToast('Copied', 'success')).catch(() => showToast('Copy failed', 'error'));
  });

  const clearBtn = document.createElement('button');
  clearBtn.textContent = 'Clear';
  clearBtn.addEventListener('click', () => {
    container.style.display = 'none';
    container.innerHTML = '';
  });

  controls.appendChild(copyBtn);
  controls.appendChild(clearBtn);
  header.appendChild(controls);
  wrapper.appendChild(header);

  const body = document.createElement('pre');
  body.style.whiteSpace = 'pre-wrap';
  body.style.wordBreak = 'break-word';
  body.style.fontFamily = 'monospace';
  body.style.fontSize = '13px';
  const text = (typeof data === 'object') ? JSON.stringify(data, null, 2) : String(data);
  body.textContent = text;
  wrapper.appendChild(body);

  container.appendChild(wrapper);
}