// api-client.js
// Lightweight resilient client: timeout, retries with exponential backoff + jitter,
// concurrency limiting, simple circuit-breaker.
// Usage: await apiClient.request(url, { method: 'GET' }, { retries: 3, timeout: 9000 });

const apiClient = (() => {
  const DEFAULTS = {
    timeout: 10000,
    retries: 3,
    backoffBase: 250,
    backoffMax: 5000,
    jitter: true,
    concurrency: 6,
    circuitThreshold: 6,
    circuitResetMs: 30000,
    fallbackUrls: []
  };

  let inFlight = 0;
  const queue = [];
  const circuit = { failures: 0, state: 'CLOSED', openedAt: 0 };

  const wait = ms => new Promise(r => setTimeout(r, ms));
  const now = () => Date.now();

  function calcBackoff(attempt, base, max, jitter) {
    const exp = Math.min(max, base * (2 ** (attempt - 1)));
    if (!jitter) return exp;
    return Math.floor(Math.random() * exp);
  }

  function runQueue() {
    if (inFlight >= DEFAULTS.concurrency) return;
    const item = queue.shift();
    if (!item) return;
    inFlight++;
    item.fn().then(item.resolve, item.reject).finally(() => {
      inFlight--;
      setTimeout(runQueue, 0);
    });
  }

  function enqueue(fn) {
    return new Promise((resolve, reject) => {
      queue.push({ fn, resolve, reject });
      runQueue();
    });
  }

  function shouldShortCircuit() {
    if (circuit.state === 'OPEN') {
      if (now() - circuit.openedAt > DEFAULTS.circuitResetMs) {
        circuit.state = 'HALF';
        return false;
      }
      return true;
    }
    return false;
  }

  function recordSuccess() {
    circuit.failures = 0;
    if (circuit.state === 'HALF') circuit.state = 'CLOSED';
  }

  function recordFailure() {
    circuit.failures++;
    if (circuit.failures >= DEFAULTS.circuitThreshold) {
      circuit.state = 'OPEN';
      circuit.openedAt = now();
    }
  }

  async function attemptFetch(url, opts, timeout) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, Object.assign({}, opts, { signal: controller.signal }));
      clearTimeout(id);
      if (!response.ok) {
        const txt = await response.text().catch(() => '');
        const err = new Error(`HTTP ${response.status} ${txt || response.statusText}`);
        err.status = response.status;
        throw err;
      }
      const ct = (response.headers.get('content-type') || '');
      if (ct.includes('application/json')) return await response.json();
      return await response.text();
    } catch (err) {
      clearTimeout(id);
      throw err;
    }
  }

  async function request(url, opts = {}, cfg = {}) {
    const settings = Object.assign({}, DEFAULTS, cfg);

    if (shouldShortCircuit()) throw new Error('Service temporarily unavailable');

    const exec = async () => {
      let lastErr = null;
      const candidates = [url].concat(settings.fallbackUrls || []);
      for (let c = 0; c < candidates.length; c++) {
        const candidate = candidates[c];
        for (let attempt = 1; attempt <= settings.retries; attempt++) {
          try {
            const res = await attemptFetch(candidate, opts, settings.timeout);
            recordSuccess();
            return res;
          } catch (err) {
            lastErr = err;
            const status = err.status;
            const isNetwork = err.name === 'AbortError' || err instanceof TypeError;
            const retryableStatus = !status || status >= 500 || status === 429;
            if (!isNetwork && !retryableStatus) {
              break;
            }
            if (attempt < settings.retries) {
              const delay = calcBackoff(attempt, settings.backoffBase, settings.backoffMax, settings.jitter);
              await wait(delay);
              continue;
            }
          }
        }
      }
      recordFailure();
      throw lastErr || new Error('Request failed');
    };

    return enqueue(exec);
  }

  return { request, defaults: DEFAULTS, setFallbacks(urls) { DEFAULTS.fallbackUrls = urls; }, getCircuit: () => ({ ...circuit }) };
})();