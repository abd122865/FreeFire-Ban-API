const CONFIG = {
  API_BASE: 'https://supra-7-x-pp.vercel.app'
};