# SUPRA7X — Frontend + Proxy

Overview
- Frontend: static files (public/) — suitable for surge.sh.
- Backend proxy: Node.js (server-proxy.js) — must be deployed separately (Render, Heroku, Railway, VPS, etc.)

Backend (server) — تشغيل محليًا
1. انسخ هذا المستودع إلى جهازك.
2. في جذر المشروع: `npm install`
3. انشئ ملف `.env` بناءً على `.env.example` واضبط `ALLOWED_ORIGIN` لنطاق واجهتك (مثال: `https://your-site.surge.sh`).
4. تشغيل: `npm start`
5. تحقق: `http://localhost:3000/health`

Frontend (surge) — تحضير ونشر
1. افتح `public/static/js/config.js` وعدّل `API_BASE` إلى عنوان البروكسي (مثال أثناء الاختبار: `http://localhost:3000`، بعد النشر: `https://proxy.example.com`).
2. ثبت surge: `npm i -g surge`
3. من جذر المشروع نفّذ: `surge ./public your-name.surge.sh`
4. تأكد أن `ALLOWED_ORIGIN` في الخادم يتطابق مع `https://your-name.surge.sh`.

Local dev (static server)
- لتقديم الملفات محليًا: `npm i -g serve` ثم `serve public -p 5000`
- افتح: `http://localhost:5000/tools/convert.html` (API_BASE = http://localhost:3000)

Security notes
- لا تضع مفاتيح سرية في الواجهة.
- اضبط `ALLOWED_ORIGIN` بدقة.
- استخدم HTTPS في الإنتاج.
- استبدل التخزين المؤقت في الذاكرة بـ Redis للإنتاج إن احتجت.