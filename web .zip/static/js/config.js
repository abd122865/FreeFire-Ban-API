// تغيير هذا قبل النشر إلى عنوان البروكسي الفعلي (مثال: https://proxy.example.com)
// لا تضع "/" في النهاية
window.SUPRA_CONFIG = {
  API_BASE: 'https://YOUR-PROXY-ORIGIN.COM' // <-- استبدل هذا بالقيمة الفعلية قبل النشر
};