// server-proxy.js
// تشغيل: npm install ثم npm start
// الحزم المطلوبة: express, node-fetch, express-rate-limit, node-cache, helmet, express-validator, dotenv

const express = require('express');
const fetch = require('node-fetch');
const rateLimit = require('express-rate-limit');
const NodeCache = require('node-cache');
const helmet = require('helmet');
const { query, validationResult } = require('express-validator');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const cache = new NodeCache({ stdTTL: 20, checkperiod: 60 });

// Production: ضع origin الخاص بالـ surge هنا (مثال: https://your-site.surge.sh)
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';

app.use(helmet({
  contentSecurityPolicy: false
}));

// CSP header صارم (تعديل حسب حاجتك)
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'none'; connect-src 'self'; script-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline';");
  next();
});

// CORS: السماح للأصل المصرح فقط (أو '*' للتطوير)
app.use((req, res, next) => {
  if (ALLOWED_ORIGIN) {
    res.header('Access-Control-Allow-Origin', ALLOWED_ORIGIN);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  res.header('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// rate limiter (تعديل القيم حسب الحاجة)
const limiter = rateLimit({
  windowMs: 15 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// نقاط النهاية upstream (إن أردت تغيّرها هنا)
const UPSTREAM = {
  convert: 'https://get-access-token.vercel.app/Eat?eat_token=',
  guestBase: 'https://get-access-token-supra-7x.vercel.app/api/get-token?uid=',
  guestPassParam: '&password=',
  revoke: 'https://token-revoke-omega.vercel.app/logout?access_token=',
  ban: 'https://freefire-ban-api.onrender.com/login?access_token=',
  banRegionParam: '&region='
};

// fetch مع retries بسيطة
async function fetchWithRetries(url, opts = {}, retries = 2) {
  let lastErr;
  for (let i = 0; i <= retries; i++) {
    try {
      const r = await fetch(url, opts);
      if (!r.ok) {
        const text = await r.text().catch(() => '');
        const err = new Error(`Upstream ${r.status} ${text || r.statusText}`);
        err.status = r.status;
        throw err;
      }
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('application/json')) return await r.json();
      return await r.text();
    } catch (err) {
      lastErr = err;
      await new Promise(res => setTimeout(res, 200 * (i + 1)));
    }
  }
  throw lastErr;
}

// تجنّب تسريب التوكنات في السجلات
function safeLog(...args) {
  console.log(...args.map(a => (typeof a === 'string' && a.length > 200) ? a.slice(0, 200) + '...[truncated]' : a));
}

// Validators
const validateEat = [ query('eat').isString().isLength({ min: 20, max: 500 }) ];
const validateGuest = [ query('uid').isString().isLength({ min: 2, max: 150 }), query('password').isString().isLength({ min: 2, max: 150 }) ];
const validateRevoke = [ query('token').isString().isLength({ min: 10, max: 500 }) ];
const validateBan = [ query('token').isString().isLength({ min: 10, max: 500 }), query('region').isString().isIn(['IND','ME','VN','BD','PK','SG','BR','NA','ID','RU','TH','TW','EU']) ];

app.get('/api/convert', validateEat, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: 'Invalid input' });

  const eat = req.query.eat;
  const cacheKey = `convert:${eat.slice(0, 40)}`;
  const cached = cache.get(cacheKey);
  if (cached) return res.json(cached);

  try {
    const url = UPSTREAM.convert + encodeURIComponent(eat);
    const data = await fetchWithRetries(url, { method: 'GET' }, 3);
    cache.set(cacheKey, data, 10);
    return res.json(data);
  } catch (err) {
    safeLog('convert error:', err.message);
    return res.status(err.status || 502).json({ error: 'Upstream failed' });
  }
});

app.get('/api/guest', validateGuest, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: 'Invalid input' });

  const uid = req.query.uid;
  const password = req.query.password;
  try {
    const url = UPSTREAM.guestBase + encodeURIComponent(uid) + UPSTREAM.guestPassParam + encodeURIComponent(password);
    const data = await fetchWithRetries(url, { method: 'GET' }, 3);
    return res.json(data);
  } catch (err) {
    safeLog('guest error:', err.message);
    return res.status(err.status || 502).json({ error: 'Upstream failed' });
  }
});

app.get('/api/revoke', validateRevoke, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: 'Invalid input' });

  const token = req.query.token;
  try {
    const url = UPSTREAM.revoke + encodeURIComponent(token);
    const data = await fetchWithRetries(url, { method: 'GET' }, 3);
    return res.json(data);
  } catch (err) {
    safeLog('revoke error:', err.message);
    return res.status(err.status || 502).json({ error: 'Upstream failed' });
  }
});

app.get('/api/ban', validateBan, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: 'Invalid input' });

  const token = req.query.token;
  const region = req.query.region;
  try {
    const url = UPSTREAM.ban + encodeURIComponent(token) + UPSTREAM.banRegionParam + encodeURIComponent(region);
    const data = await fetchWithRetries(url, { method: 'GET' }, 3);
    return res.json(data);
  } catch (err) {
    safeLog('ban error:', err.message);
    return res.status(err.status || 502).json({ error: 'Upstream failed' });
  }
});

app.get('/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

app.listen(PORT, () => {
  console.log(`Proxy listening on :${PORT}`);
});